<h1 align="center"> Jajiga  :)) </h1>
</br>
<img src="./public/images/jajiga.jpg" width="100%"></img> 
</br>

## 📛📛 Please turn off the Vpn to visit this website

<div>

[View Online](https://jajiga.liara.run/)

 </div>
